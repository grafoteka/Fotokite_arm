^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_rotors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.1.1 (2017-04-27)
-----------
* Update maintainers.
* Contributors: Timo Hinzmann
